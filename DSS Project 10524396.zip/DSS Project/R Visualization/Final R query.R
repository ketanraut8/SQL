install.packages(RODBC)
Require(RODBC)
# Connecting to the database
conn = odbcDriverConnect("Driver={SQL Server};server=LAPTOP-SASDLFI4\SQLSERVER;database=[Final_Assignment];trusted_connection=true")
conn

server <- "LAPTOP-SASDLFI4\\SQLSERVER"
database<- "sample"
connectionString <- paste0("Driver={SQL Server};server=",server,";database=",database,";trusted_connection=yes;")
conn <-  odbcDriverConnect(connection=connectionString)

#To visualise department and payrate.

r1 = sqlQuery(conn,"SELECT e.Department,max(a.payrate) as payrate from Dim_Department e 
inner join Dim_fact a on e.Dept_key=a.Dept_key group by e.Department")
r1
names(r1)=c("Department","Payrate")
r1
ggplot(r1,aes(Department,payrate))+geom_bar(stat="identity",aes(fill = Department))

# Visualising the Employee joining year. 
r2 = sqlQuery(conn,"
SELECT  year, count(EmpID) as Employee FROM HRDataset_v13$ group by Year ")
r2
names(r2)=c("year","Employee")
r2
ggplot(r2,aes(year,Employee))+geom_bar(stat="identity",aes(fill = Employee))

#Visualising performance score of the employees
r3 = sqlQuery(conn,"SELECT  PerformanceScore as Performance,
              count(empID) as Employees FROM HRDataset_v13$ 
              Group by PerformanceScore order by Employees DESC")
r3
names(r3) = c("Performance","Employees")
r3
ggplot(r3,aes(Performance,Employees))+geom_bar(stat = "identity",
                                               aes(fill = Performance))

# Visualising total no of Recruitment monthwise
r4 = sqlQuery(conn,"SELECT Month, count(EmpID) as Total_Recruitment FROM HRDataset_v13$ group by Month")
r4
names(r4) = c("Month","Total_Recruitment")
r4
ggplot(r4,aes(y=Total_Recruitment,x=Month))+geom_bar(stat = "identity",
                                               aes(fill = Month))
       



